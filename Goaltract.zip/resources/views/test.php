
                    <div class="form-group">
                      <label>misc.campaign_description</label>
                      	<textarea name="description" rows="4" id="description" class="form-control" placeholder="misc.campaign_description_placeholder">{{ old('description') }}</textarea>
                        <small class="text-muted">misc.campaign_description_placeholder</small>
                    </div>



<script src="{{ asset('public/js/ckeditor/ckeditor.js')}}"></script>
